function calculate(x){

    result.value = result.value + x;
}